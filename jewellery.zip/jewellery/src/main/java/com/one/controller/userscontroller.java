package com.one.controller;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.one.entity.User;
import com.one.exception.Resourcenotfoundexception;
import com.one.repository.UserRepository;

import antlr.collections.List;



@RestController
@RequestMapping("/api/members")
public class userscontroller {

	
	@Autowired
	public UserRepository userRepository;
	
	//get all members
	@GetMapping
	public List<User>getAllMembers(){
		return this.userRepository.findAll();
	}
		//get members by id
	@GetMapping("/{id}")
		public User getMembersById(@PathVariable (value = "id") long membersId) {
			return this.userRepository.findById(membersId)
					.orElseThrow(()->new Resourcenotfoundexception("user not found with id:" + membersId));
	}
	//create Members
	@PostMapping
	public User createUser(@RequestBody User user) {
		
		return this.userRepository.save(user);
	}
			//update Members
	@PutMapping("/{id}")
	public User updateMembers(@RequestBody User members,@PathVariable("id") long membersId) {
		User existingMembers =  this.userRepository.findById(membersId)
				.orElseThrow(()->new Resourcenotfoundexception("user not found with id:" + membersId));
		existingMembers.setFirstName(members.getFirstName());
		existingMembers.setLastName(members.getLastName());
		existingMembers.setEmail(members.getEmail());
		existingMembers.setAddress(members.getAddress());
		return this.userRepository.save(existingMembers);
	}
	//delete Members by id
	@DeleteMapping("/{id}")
	public ResponseEntity<User> deleteMembers(@PathVariable ("id")long membersId){
		User existingMembers =  this.userRepository.findById(membersId)
				.orElseThrow(()->new Resourcenotfoundexception("user not found with id:" + membersId));
		this.userRepository.delete(existingMembers);
		return ResponseEntity.ok().build();
		
		
	}

		}
		
	
	

